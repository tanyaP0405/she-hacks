function calculateLog() {
    // Get the input value
    var inputelement = document.getElementById('calculatelog').value;
    var basevalue = document.getElementById('basevalue').value;
    var resultelement = document.getElementById('result');

    // Check if the input is a valid number
    if(isNaN(inputelement) || inputelement<=0){
        alert('Please enter a valid positive number');
        return;

    }
    if(isNaN(basevalue) || basevalue<=0 || basevalue==1){
        alert('Please enter a valid base');
        return;
    }


    // Calculate the logarithm
    var answer = Math.log(basevalue)(inputNumber);

    // Display the result
    resultelement.textContent="The log of the given number is:" + answer.tofixed(4);
}
